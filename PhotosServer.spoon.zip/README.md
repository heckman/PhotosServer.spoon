# PhotosServer.spoon

This is a Spoon for [Hammerspoon](https://www.hammerspoon.org/)
that serves photos from the
[Apple Photos](https://apps.apple.com/app/photos/id1584215428) application
on localhost.

** THIS IS NOT DONE, WHAT FOLLOWS HAS BEEN TAKEN FROM AN OLD PROJECT.
I AM IN THE PROGRESS OF REWRITING IT FOR THE HAMMERSPOON VERSION. **

## Usage

### Naming the server

If you'd like to refer to the server by name,
rather that as `localhost:6330`,
it can be accomplished by editing some system files.

> **WARNING**: This is not for the faint of heart. Doing this wrong could be VERY VERY VERY bad. Don't do this unless you know what you're doing. If it goes horrible bad it is absolutely not my fault.

#### Forward port 6330

Add this line to a new file at `/etc/pf.anchors/com.local.redirect` to make a new rule:

```conf
rdr pass on lo0 inet proto tcp from any to 127.0.0.3 port 80 -> 127.0.0.3 port 6330
```

Now enable the rule in `/etc/pf.conf`, add the lines with `com.local.redirect` after the existing rules of their respective types, that is to satm the new `rdr-anchor` line after the existing `rdr-anchor` lines, and the new `load anchor` line after the existing `load anchor` lines.

```shell
scrub-anchor "com.apple/*"
nat-anchor "com.apple/*"
rdr-anchor "com.apple/*"
rdr-anchor "com.local.redirect"
dummynet-anchor "com.apple/*"
anchor "com.apple/*"
load anchor "com.apple" from "/etc/pf.anchors/com.apple"
load anchor "com.local.redirect" from "/etc/pf.anchors/com.local.redirect"
```

Now flush the rules with `sudo pfctl -f /etc/pf.conf` which will produce a warning that flushing the rules can mess up your system's existing rules, which is fine.

That takes care of forwarding the port.
Now a request to `127.0.0.3:6330` will be redirected to `127.0.0.3:80`.

Now to add the pretty name. Add lines to `/etc/hosts`
to assign names to `127.0.0.3`.
I used added these:

```plain-text
127.0.0.3       photos
127.0.0.3       photos.local
127.0.0.3       photos.app
```

The only one that worked was `photos.local` so I removed the other two—it's the only one my system would let me access via http rather than https. Also, safari kept adding `.com` to the the plain `photos`.

### Automated installation

> **Warning**: it's probably not a good idea to use this. It is not my fault if you do and things go poorly.

> **Warning**: I haven't used this script since I last edited it, so anything could happen. Really, don't use it!

There is an script called `install.sh` which will copy
the source files to the locations noted above.

Don't run it unless you've grokked the script's source code
and edited it to suit your environment.

The script will not modify `/etc/hosts`; that has to be done manually.

The automated installation does not install
(nor check for the presense of)
the required utilities `trurl` and `greadlink`.

## License

This project is shared under the GNU v3.0 General Public License,
except for the two SVG icons whose copyrights are not held by me:

- The 'broken image' icon was created for Netscape Navigator
  by Marsh Chamberlin (<https://dataglyph.com>).
  The icon's [SVG code](https://gist.github.com/diachedelic/cbb7fdd2271afa52435b7d4185e6a4ad)
  was hand-coded by github user [diachedelic](https://gist.github.com/diachedelic).

- The 'sad mac' icon was created for Apple Inc.
  by Susan Kare (<https://kareprints.com>).
  I hand-crafted the SVG which is embedded in the source code for the response handler.
