# PhotosServer.spoon

A Spoon for [Hammerspoon](https://www.hammerspoon.org/)
that serves photos from the
[Apple Photos](https://apps.apple.com/app/photos/id1584215428) Library on localhost via HTTP.
